# Changelog

## 0.1.1 — 2026-09-02

**Terceiro entry point: `bandeira-shell/native`.** `BsPlatformService`, `BsNativeShellService` e
`provideShellNative()` saíram do entry point default pra cá. Achado empacotando o `fluxo-front`
(um app 100% web, sem Capacitor instalado): ng-packagr gera UM arquivo FESM por entry point, então
`import { provideShellTheme } from 'bandeira-shell'` sozinho já obrigava o build a resolver
`@capacitor/core`/`app`/`splash-screen`/`status-bar` — mesmo o app nunca usando
`BsNativeShellService` — porque esses `import` ficavam no MESMO arquivo físico. `peerDependenciesMeta.optional`
no `package.json` só silencia o aviso do `npm install`; não livra o bundler de precisar resolver o
módulo se ele está fisicamente no mesmo arquivo. `provideShell()` (o açúcar do entry point default)
não inclui mais a parte nativa — chame `provideShellNative(...)` de `bandeira-shell/native`
separadamente quando o app roda em Capacitor.

## 0.1.0 — 2026-09-01

Primeira extração, a partir do app shell do `vitality-front`:

- `BsShellComponent` — grid sidebar/topbar responsivo, bottom-nav + bottom-sheet "mais" abaixo de
  900px, toggle sidebar/horizontal, dropdown de tema e de paleta embutidos; conteúdo específico do
  app entra via slots de projeção (`bsShellBrand`, `bsShellGreeting`, `bsShellTopActions`,
  `bsShellSidebarFooter`, `bsShellOverlays`).
- `BsThemeService` / `provideShellTheme()` — tema claro/escuro.
- `BsPaletteService` / `provideShellPalette()` / `BsPalettePickerComponent` — paletas trocáveis
  (o pacote não dita cores; ver `styles/_palette-contract.scss`).
- `BsNavigationLayoutService`, `BsNavigationProgressService` — toggle sidebar/horizontal e
  indicador de navegação em andamento.
- `BsOverlayStackService` — pilha de overlays fecháveis pelo topo (usada pelo botão físico voltar).
- `BsPlatformService`, `BsNativeShellService` / `provideShellNative()` — comportamento nativo
  Capacitor (botão voltar, barra de status, splash, revalidação de sessão), desacoplado de
  `AuthService`/serviço de toast concretos via hooks (`onExitConfirmRequested`, `onResume`).
- `provideShell()` — açúcar que agrega os `provide*()` acima.
- `generateAntiFlashScript()` — gera o snippet do script anti-flash de tema/paleta para o
  `index.html`, a partir da mesma lista de paletas usada em `provideShellPalette()`.
