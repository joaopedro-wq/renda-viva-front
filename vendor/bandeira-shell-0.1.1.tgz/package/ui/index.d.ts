import * as _angular_core from '@angular/core';
import { Signal } from '@angular/core';
import { Router } from '@angular/router';
import { BsThemeService, BsPaletteService, BsNavigationLayoutService, BsNavigationProgressService, resolveShellLabel, ShellNavItem, ShellPaletteOption } from 'bandeira-shell';

/**
 * Rótulos/aria-labels do motor de shell. O pacote não força i18n — todos têm
 * default em inglês; o app consumidor sobrescreve via `[labels]` (string fixa
 * ou, se precisar reagir a troca de idioma em runtime, um objeto recalculado
 * num `computed()` do próprio app).
 */
interface ShellLabels {
    mainNav: string;
    profile: string;
    account: string;
    palette: string;
    lightTheme: string;
    darkTheme: string;
    horizontalMenu: string;
    sidebarMenu: string;
    close: string;
    moreOptions: string;
    more: string;
    loading: string;
}
declare const DEFAULT_SHELL_LABELS: ShellLabels;

/**
 * Motor genérico de app shell: grid sidebar+topbar (ou nav horizontal),
 * bottom-nav + bottom-sheet "mais" abaixo de 900px, tema, paleta e toggle de
 * layout embutidos. Conteúdo específico do app (logo, saudação, ações extra
 * da topbar, rodapé de perfil, overlays como diálogo de sessão/onboarding)
 * entra via slots de projeção — ver `bsShellBrand`, `bsShellGreeting`,
 * `bsShellTopActions`, `bsShellSidebarFooter`, `bsShellOverlays` no template.
 */
declare class BsShellComponent {
    private readonly items;
    protected readonly theme: BsThemeService;
    protected readonly palette: BsPaletteService;
    protected readonly navigationLayout: BsNavigationLayoutService;
    protected readonly progress: BsNavigationProgressService;
    private readonly overlays;
    protected readonly router: Router;
    private paletteControl?;
    readonly labels: _angular_core.InputSignal<ShellLabels>;
    readonly showLayoutToggle: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showPalettePicker: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor();
    private registrarOverlay;
    protected readonly resolveLabel: typeof resolveShellLabel;
    /**
     * `item.data['tour']`, se presente, ganha o sufixo de superfície
     * (`-desktop`/`-mobile`) — convenção comum para bibliotecas de tour guiado
     * apontarem para o elemento visível em cada breakpoint (só um dos dois
     * existe no DOM ativo por vez, mas o app pode targetar os dois seletores).
     */
    protected tourAttr(item: ShellNavItem, surface: 'desktop' | 'mobile'): string | null;
    protected readonly navItemsVisiveis: Signal<ShellNavItem[]>;
    protected readonly mobileNavItems: Signal<ShellNavItem[]>;
    protected readonly mobileMoreItems: Signal<ShellNavItem[]>;
    protected readonly mobileMoreOpen: _angular_core.WritableSignal<boolean>;
    protected readonly paletaMenuAberto: _angular_core.WritableSignal<boolean>;
    toggleMobileMore(): void;
    closeMobileMore(): void;
    protected isMobileMoreActive(): boolean;
    togglePaletaMenu(): void;
    escolherPaleta(id: string): void;
    protected onEscape(): void;
    protected onDocumentClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BsShellComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BsShellComponent, "bs-shell", never, { "labels": { "alias": "labels"; "required": false; "isSignal": true; }; "showLayoutToggle": { "alias": "showLayoutToggle"; "required": false; "isSignal": true; }; "showPalettePicker": { "alias": "showPalettePicker"; "required": false; "isSignal": true; }; }, {}, never, ["[bsShellBrand]", "[bsShellSidebarFooter]", "[bsShellGreeting]", "[bsShellTopActionsBefore]", "[bsShellTopActions]", "[bsShellOverlays]"], true, never>;
}

declare class BsPalettePickerComponent {
    readonly paletas: _angular_core.InputSignal<readonly ShellPaletteOption[]>;
    readonly ativa: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly escolher: _angular_core.OutputEmitterRef<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BsPalettePickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BsPalettePickerComponent, "bs-palette-picker", never, { "paletas": { "alias": "paletas"; "required": true; "isSignal": true; }; "ativa": { "alias": "ativa"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "escolher": "escolher"; }, never, never, true, never>;
}

export { BsPalettePickerComponent, BsShellComponent, DEFAULT_SHELL_LABELS };
export type { ShellLabels };
