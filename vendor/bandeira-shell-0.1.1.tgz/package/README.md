<div align="center">

# bandeira-shell

**Pare de reconstruir o casco do app a cada projeto novo.**

Sidebar responsiva, tema claro/escuro, paletas trocáveis e botão físico de voltar no Capacitor —
resolvidos uma vez, configurados via `provide*()`, com a marca e o conteúdo inteiramente seus.

[![license](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)
[![Angular](https://img.shields.io/badge/Angular-20%2B-dd0031.svg)](https://angular.dev)
[![standalone](https://img.shields.io/badge/standalone-signals-42a5f5.svg)](#)

[Changelog](./CHANGELOG.md) · [Contrato de paleta](./projects/bandeira-shell/styles/_palette-contract.scss)

</div>

---

## O problema

Todo app novo recomeça o mesmo trabalho: uma sidebar que vira barra inferior no celular, um menu
"mais" que junta o que não coube, tema claro/escuro persistido sem piscar no primeiro paint,
paletas de marca trocáveis, e — se o app roda em Capacitor — o botão físico de voltar fazendo a
coisa certa (fecha overlay, depois navega, só sai no segundo toque). Nada disso é específico do
seu domínio, e ainda assim é reescrito, com pequenas variações e os mesmos bugs, projeto após
projeto.

A `bandeira-shell` resolve o casco uma vez. O que sobra pra cada app escrever é só o que o torna
único: a marca, os itens de menu, as cores.

| Camada     | O que entrega                                                                                          |
| ---------- | ------------------------------------------------------------------------------------------------------ |
| **Motor**  | `<bs-shell>` — grid responsivo, bottom-nav + bottom-sheet abaixo de 900px, toggle sidebar↔horizontal. |
| **Estado** | Tema, paleta e layout como signals persistidos, com script anti-flash pronto pro `index.html`.         |
| **Nativo** | Botão físico de voltar, barra de status e splash resolvidos — puro no-op fora do Capacitor.            |

## Instalação

Ainda não publicado em registry — distribuído como tarball local (mesmo fluxo de qualquer pacote
`file:` no npm):

```bash
npm run pack:lib                          # gera dist/bandeira-shell-<versão>.tgz
cp dist/bandeira-shell-*.tgz ../seu-app/vendor/
```

```json
// package.json do app consumidor
"dependencies": {
  "bandeira-shell": "file:vendor/bandeira-shell-0.1.0.tgz"
}
```

Peer dependencies: `@angular/core`/`@angular/common`/`@angular/router` `>=20`, `@lucide/angular`,
e [`bandeira-ui`](https://www.npmjs.com/package/bandeira-ui) (usada internamente pelo botão e
tooltip do shell). `@capacitor/*` são opcionais — só entram se o app roda nativo.

## Três entry points, de propósito

```ts
import { provideShellTheme } from 'bandeira-shell'; // leve: tema/paleta/navegação/overlay
import { BsShellComponent } from 'bandeira-shell/ui'; // o componente em si, com Router + ícones
import { provideShellNative } from 'bandeira-shell/native'; // só quem roda em Capacitor
```

Cada entry point vira **um único arquivo** no pacote publicado — então importar até um símbolo
sozinho de um entry point resolve TODOS os imports daquele arquivo, usados ou não. Um app 100% web
nunca deveria precisar instalar `@capacitor/*` só porque importou `provideShellTheme`, e um guard
de rota que só quer saber se o app é nativo não deveria pagar o peso de renderizar a sidebar.
`bandeira-shell` (default) fica só com os serviços leves — tema, paleta, navegação, overlay; sem
Router, sem `bandeira-ui`, sem `@capacitor/*`. `bandeira-shell/ui` tem o componente visual.
`bandeira-shell/native` tem `BsPlatformService`/`BsNativeShellService` — o único lugar que resolve
`@capacitor/*`. Cada import puxa só o que usa.

## Uso básico

```ts
// app.config.ts
import { ApplicationConfig } from '@angular/core';
import { provideShell } from 'bandeira-shell';
import { LucideHouse, LucideUser } from '@lucide/angular';

export const appConfig: ApplicationConfig = {
  providers: [
    // ...
    provideShell({
      palette: {
        options: [{ id: 'default', label: 'Padrão', swatch: '#5c7a3f' }],
        defaultId: 'default',
      },
      navigation: [
        { path: '/dashboard', label: 'Dashboard', icon: LucideHouse },
        { path: '/perfil', label: 'Perfil', icon: LucideUser },
      ],
    }),
  ],
};
```

```ts
// shell.component.ts do app consumidor
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { BsShellComponent } from 'bandeira-shell/ui';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [BsShellComponent, RouterLink],
  template: `
    <bs-shell>
      <a bsShellBrand routerLink="/dashboard">Minha marca</a>
      <span bsShellGreeting>Olá!</span>
      <div bsShellTopActions>
        <button (click)="logout()">Sair</button>
      </div>
    </bs-shell>
  `,
})
export class AppShellComponent {
  logout() {
    /* ... */
  }
}
```

O motor cuida do resto: grid, breakpoints, bottom-nav, dropdown de tema e de paleta. Nenhuma marca,
nenhum texto fixo, nenhuma rota hardcoded — tudo isso é o que você acabou de passar.

## Slots de projeção

`<bs-shell>` é dono da estrutura (grid, breakpoints, mobile-nav, dropdowns de tema/paleta); o
conteúdo específico do seu app entra por atributo, na ordem em que aparecem na topbar/sidebar:

| Slot                      | Onde aparece                                              |
| ------------------------- | --------------------------------------------------------- |
| `bsShellBrand`            | Logo, no topo da sidebar.                                 |
| `bsShellSidebarFooter`    | Rodapé da sidebar — normalmente avatar + link de perfil.  |
| `bsShellGreeting`         | Início da topbar — saudação, título de página, etc.       |
| `bsShellTopActionsBefore` | Topbar, antes dos controles nativos (layout/paleta/tema). |
| `bsShellTopActions`       | Topbar, depois dos controles nativos — CTA, logout.       |
| `bsShellOverlays`         | Fora do fluxo visual — diálogos, onboarding, tours.       |

## Navegação

```ts
export interface ShellNavItem {
  path: string;
  label: string | (() => string); // string fixa OU getter — sem i18n forçado
  mobileLabel?: string | (() => string);
  icon: LucideIcon;
  visible?: () => boolean; // reavaliado a cada render — ex.: só admin
  mobileSlot?: 'bar' | 'more'; // <900px: barra fixa ou gaveta "mais"
  data?: Record<string, string>; // bag livre — ex.: alvo de um tour guiado
}
```

## Tema e paletas

O pacote não dita cores — cada app é dono da própria marca. Ele define o _mecanismo_ (signal +
`data-theme`/`data-palette` no `documentElement` + `localStorage`) e um contrato de tokens:

```scss
// styles.scss do app consumidor
@use 'bandeira-shell/styles/palette-contract' as shell;

@include shell.bs-palette(
  'default',
  $primary: #5c7a3f,
  $primary-strong: #47622f,
  $primary-soft: rgba(92, 122, 63, 0.14),
  $primary-contrast: #fffdf7,
  $sidebar-bg: #33421f,
  $sidebar-bg-hover: #43562c,
  $sidebar-fg: #f1f4e8,
  $sidebar-fg-muted: #c2cbaa
);
```

`generateAntiFlashScript()` gera o snippet que evita o flash de tema/paleta errado antes do
Angular iniciar — chame de um script de build (Node puro; ver comentário no próprio arquivo) e
injete o resultado no `<head>` do `index.html`.

## Nativo (Capacitor)

```ts
import { provideShellNative } from 'bandeira-shell/native';

provideShellNative({
  rootRoutes: ['/dashboard', '/login', '/'],
  onExitConfirmRequested: () => toastr.info('Toque de novo para sair'),
  onResume: () => auth.restoreSession().subscribe(),
});
```

Botão físico de voltar com ordem fixa: fecha o overlay do topo (`BsOverlayStackService`) → navega
para trás → na raiz, sai só no segundo toque. Sem `@capacitor/*` instalado, ou fora do Capacitor,
tudo isso é no-op — nenhum código condicional espalhado pelo app.

## API completa

| Export                                             | O que faz                                                     |
| -------------------------------------------------- | ------------------------------------------------------------- |
| `provideShellTheme(config?)`                       | Tema claro/escuro persistido.                                 |
| `provideShellPalette(config)`                      | Paleta ativa persistida + validada contra `options`.          |
| `provideShellNavigation(items)`                    | Itens de menu (ver `ShellNavItem` acima).                     |
| `provideShell(config)`                             | Açúcar: agrega tema + paleta + navegação num só.               |
| `BsThemeService` / `BsPaletteService`              | Signal + `toggle()`/`set()`.                                  |
| `BsNavigationLayoutService`                        | Toggle sidebar ↔ horizontal, persistido.                     |
| `BsNavigationProgressService`                      | Signal `navegando` — indicador de troca de rota.              |
| `BsOverlayStackService`                            | Pilha de overlays fecháveis pelo topo.                        |
| `BsShellComponent` _(`bandeira-shell/ui`)_         | O componente `<bs-shell>` em si.                              |
| `BsPalettePickerComponent` _(`bandeira-shell/ui`)_ | Dropdown de escolha de paleta, usado internamente pelo shell. |
| `generateAntiFlashScript(ids, opts)`               | Gera o snippet anti-flash pro `index.html`.                   |
| `BsPlatformService` _(`bandeira-shell/native`)_    | `isNative`/`isAndroid`/`isIos`.                               |
| `provideShellNative(config)` _(`bandeira-shell/native`)_ | Botão voltar/barra de status/splash no Capacitor.       |

## Desenvolvimento

```bash
npm install
npm run build:lib   # ng build (dois entry points) + copia README/LICENSE/CHANGELOG pro pacote
npm run watch:lib    # rebuild incremental a cada save
npm run pack:lib     # build:lib + npm pack em dist/
npm test             # karma, headless
```

Pra iterar num app consumidor sem reempacotar a cada mudança:

```bash
# aqui, no bandeira-shell
npm run build:lib && cd dist/bandeira-shell && npm link

# no app consumidor
npm link bandeira-shell
```

E em `angular.json` do app consumidor, `"preserveSymlinks": true` nas options de build/serve —
sem isso, o resolvedor de módulos segue o link até o `node_modules` do `bandeira-shell` em vez do
`node_modules` do app, e a app acaba com duas cópias de `@angular/core` (sintoma clássico:
`NullInjectorError` ou signals que nunca disparam). Pra voltar ao tarball normal:
`npm unlink bandeira-shell && npm install`.

## Licença

[MIT](./LICENSE) © João Pedro Bandeira
