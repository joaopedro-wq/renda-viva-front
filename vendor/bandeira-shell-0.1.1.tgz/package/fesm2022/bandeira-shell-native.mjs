import * as i0 from '@angular/core';
import { Injectable, InjectionToken, makeEnvironmentProviders, inject, NgZone, effect } from '@angular/core';
import { Capacitor } from '@capacitor/core';
import { Router } from '@angular/router';
import { App } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';
import { BsOverlayStackService, BsThemeService } from 'bandeira-shell';

class BsPlatformService {
    isNative = Capacitor.isNativePlatform();
    isAndroid = Capacitor.getPlatform() === 'android';
    isIos = Capacitor.getPlatform() === 'ios';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPlatformService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPlatformService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPlatformService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const SHELL_NATIVE_CONFIG = new InjectionToken('SHELL_NATIVE_CONFIG');
const NOOP = () => { };
function provideShellNative(config) {
    return makeEnvironmentProviders([
        {
            provide: SHELL_NATIVE_CONFIG,
            useValue: {
                exitConfirmWindowMs: 2000,
                onExitConfirmRequested: NOOP,
                onResume: NOOP,
                autoStart: true,
                ...config,
            },
        },
    ]);
}

/**
 * Comportamento nativo do shell no Capacitor: botão físico de voltar,
 * barra de status reagindo ao tema, splash e revalidação de sessão ao
 * voltar do segundo plano. No-op completo no navegador (`BsPlatformService.isNative`).
 */
class BsNativeShellService {
    platform = inject(BsPlatformService);
    zone = inject(NgZone);
    router = inject(Router);
    overlays = inject(BsOverlayStackService);
    theme = inject(BsThemeService);
    config = inject(SHELL_NATIVE_CONFIG);
    listeners = [];
    saidaConfirmadaAte = 0;
    iniciado = false;
    constructor() {
        // Fora do `start()` porque effect() exige contexto de injeção. Só age
        // quando o app nativo já iniciou.
        effect(() => {
            const tema = this.theme.theme();
            if (!this.platform.isNative || !this.iniciado)
                return;
            // `Style.Dark` = conteúdo claro sobre fundo escuro.
            void StatusBar.setStyle({ style: tema === 'dark' ? Style.Dark : Style.Light }).catch(() => {
                // Alguns aparelhos não expõem a barra; não é motivo para quebrar o boot.
            });
        });
    }
    /** Chamado uma vez, depois do bootstrap do Angular (ver `provideShellNative`/`autoStart`). */
    start() {
        if (!this.platform.isNative || this.iniciado)
            return;
        this.iniciado = true;
        void SplashScreen.hide().catch(() => {
            // Splash já escondida (ou plugin ausente): segue o jogo.
        });
        void App.addListener('backButton', ({ canGoBack }) => {
            this.zone.run(() => this.onBackButton(canGoBack));
        }).then((listener) => this.listeners.push(listener));
        void App.addListener('appStateChange', ({ isActive }) => {
            this.zone.run(() => this.onAppStateChange(isActive));
        }).then((listener) => this.listeners.push(listener));
    }
    async stop() {
        await Promise.all(this.listeners.map((listener) => listener.remove()));
        this.listeners.length = 0;
        this.iniciado = false;
    }
    onBackButton(canGoBack) {
        // 1. O que estiver por cima fecha primeiro.
        if (this.overlays.fecharTopo())
            return;
        // 2. Fora das raízes, voltar é navegar para trás.
        const naRaiz = this.config.rootRoutes.includes(this.router.url.split('?')[0]);
        if (canGoBack && !naRaiz) {
            window.history.back();
            return;
        }
        // 3. Na raiz, sair — mas só no segundo toque, para não fechar sem querer.
        const agora = Date.now();
        if (agora < this.saidaConfirmadaAte) {
            void App.exitApp();
            return;
        }
        this.saidaConfirmadaAte = agora + this.config.exitConfirmWindowMs;
        this.config.onExitConfirmRequested();
    }
    onAppStateChange(isActive) {
        if (!isActive)
            return;
        this.config.onResume();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNativeShellService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNativeShellService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNativeShellService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/*
 * Public API surface of bandeira-shell/native
 *
 * Terceiro entry point, separado do default e do `/ui` — só quem realmente
 * roda em Capacitor precisa resolver `@capacitor/core`/`app`/`splash-screen`/
 * `status-bar`. Um app 100% web (ex.: sem plano de virar nativo) nunca
 * instala esses pacotes, e como cada entry point vira um único arquivo FESM,
 * um import eager de QUALQUER símbolo do entry point default bastaria pra
 * exigir esses pacotes resolvidos no build — mesmo sem usá-los. Ver
 * CHANGELOG.md.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BsNativeShellService, BsPlatformService, SHELL_NATIVE_CONFIG, provideShellNative };
//# sourceMappingURL=bandeira-shell-native.mjs.map
