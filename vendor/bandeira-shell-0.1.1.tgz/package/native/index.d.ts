import * as i0 from '@angular/core';
import { InjectionToken, EnvironmentProviders } from '@angular/core';

declare class BsPlatformService {
    readonly isNative: boolean;
    readonly isAndroid: boolean;
    readonly isIos: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsPlatformService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsPlatformService>;
}

/**
 * Configuração do comportamento nativo (Capacitor) do shell — botão físico
 * de voltar, revalidação ao voltar do segundo plano, barra de status.
 * Desacoplado de qualquer `AuthService`/serviço de toast concreto: o app
 * consumidor decide o que fazer nos dois pontos de extensão (`onExitConfirmRequested`,
 * `onResume`).
 */
interface ShellNativeConfig {
    /** Rotas onde o botão voltar não navega para trás — exige duplo toque para sair. */
    rootRoutes: string[];
    /** Janela do duplo toque de saída, em ms. @default 2000 */
    exitConfirmWindowMs?: number;
    /** Chamado no primeiro toque de saída, na raiz (ex.: mostrar um toast de dica). */
    onExitConfirmRequested?: () => void;
    /** Chamado quando o app volta do segundo plano com sessão ativa (ex.: revalidar token). */
    onResume?: () => void;
    /** Chama `start()` automaticamente via `provideAppInitializer`. @default true */
    autoStart?: boolean;
}
declare const SHELL_NATIVE_CONFIG: InjectionToken<Required<ShellNativeConfig>>;
declare function provideShellNative(config: ShellNativeConfig): EnvironmentProviders;

/**
 * Comportamento nativo do shell no Capacitor: botão físico de voltar,
 * barra de status reagindo ao tema, splash e revalidação de sessão ao
 * voltar do segundo plano. No-op completo no navegador (`BsPlatformService.isNative`).
 */
declare class BsNativeShellService {
    private readonly platform;
    private readonly zone;
    private readonly router;
    private readonly overlays;
    private readonly theme;
    private readonly config;
    private readonly listeners;
    private saidaConfirmadaAte;
    private iniciado;
    constructor();
    /** Chamado uma vez, depois do bootstrap do Angular (ver `provideShellNative`/`autoStart`). */
    start(): void;
    stop(): Promise<void>;
    private onBackButton;
    private onAppStateChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsNativeShellService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsNativeShellService>;
}

export { BsNativeShellService, BsPlatformService, SHELL_NATIVE_CONFIG, provideShellNative };
export type { ShellNativeConfig };
